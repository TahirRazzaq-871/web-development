# E-Commerce Project - Assignment 3

## Project Overview
This is a full-stack e-commerce application with product listings, advanced filtering, search, sorting, and pagination.

## Technology Stack
- **Backend**: Node.js + Express
- **Database**: MongoDB
- **Frontend**: EJS + Bootstrap + CSS
- **Features**: Search, Filter (Category & Price), Sorting, Pagination

## File Structure

```
Assignment 3/
├── server.js              # Main Express server
├── seed.js                # Database seeding script
├── package.json           # Dependencies
├── .env                   # Configuration
├── models/
│   └── Product.js         # Product schema
├── routes/
│   └── products.js        # Product routes with filtering logic
└── views/
    └── products.ejs       # Product listing template
```

## Setup Instructions

### Step 1: Install Dependencies
```bash
npm install
```

### Step 2: Configure MongoDB
**Option A: Local MongoDB**
- Make sure MongoDB is running on `localhost:27017`
- The `.env` file already has the correct URI

**Option B: MongoDB Atlas (Cloud)**
- Create account on [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
- Create a cluster and get connection string
- Update `.env` file:
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/ecommerce
```

### Step 3: Seed Database
```bash
npm run seed
```
This adds 25 sample products to the database.

### Step 4: Start Server
```bash
npm start
```
Server runs on: `http://localhost:3000`

## Features Explained

### 1. Product Schema
```javascript
{
  name: String,
  price: Number,
  category: String,
  rating: Number,
  stock: Number,
  image: String (URL),
  description: String
}
```

### 2. Search
- URL: `?search=phone`
- Searches product names using regex (case-insensitive)
- Example: `/products?search=shoe`

### 3. Category Filter
- URL: `?category=Electronics`
- Available categories: Electronics, Fashion, Shoes, Home, Books
- Example: `/products?category=Fashion`

### 4. Price Filter
- URL: `?minPrice=1000&maxPrice=5000`
- Filters products within price range
- Example: `/products?minPrice=500&maxPrice=3000`

### 5. Sorting
- Default: No sorting
- `?sort=price_asc` - Price Low to High
- `?sort=price_desc` - Price High to Low
- `?sort=rating_desc` - Rating High to Low
- Example: `/products?sort=rating_desc`

### 6. Pagination
- Shows 8 products per page
- URL: `?page=1`
- Uses `skip` and `limit` in MongoDB
- Previous/Next buttons navigate pages
- Example: `/products?page=2`

### 7. Filter Persistence
All filters stay active when changing pages:
```
/products?page=2&search=phone&category=Electronics&minPrice=1000&maxPrice=5000&sort=price_asc
```

## How to Use

1. **View All Products**: Go to `/products`
2. **Search**: Type in search box and click "Search & Filter"
3. **Filter by Category**: Select from dropdown
4. **Filter by Price**: Enter min and max prices
5. **Sort**: Select sorting option
6. **Paginate**: Use Previous/Next buttons
7. **Reset**: Click Reset button to clear all filters

## Database Seeding

The seed file includes 25 sample products from 5 categories:
- **Electronics**: Headphones, Cable, Phone Protector, Smart Watch, Speaker, Memory Card
- **Fashion**: T-Shirt, Jeans, Jacket
- **Shoes**: Running Shoes, Casual Sneakers, Formal Shoes, Kids Shoes
- **Home**: Coffee Maker, Lamp, Bed Sheet, Knife Set, Microwave, Blender, Wall Clock
- **Books**: Great Gatsby, Python Programming, Web Design, Database Design, Web Development

## Code Flow

### Backend Flow:
1. User visits `/products` with query parameters
2. `routes/products.js` receives the request
3. Builds MongoDB filter object
4. Applies sorting
5. Uses skip/limit for pagination
6. Returns data to `products.ejs` template

### Frontend Flow:
1. Form submits with filter values
2. Query parameters are preserved in pagination links
3. Products display in responsive grid
4. Previous/Next buttons include all active filters

## Pagination Logic

```javascript
itemsPerPage = 8;
skip = (page - 1) * 8;
// Page 1: skip 0, show 1-8
// Page 2: skip 8, show 9-16
// Page 3: skip 16, show 17-24
```

## Filter Persistence Example

When user searches for "shoe" and goes to page 2:
- Search box shows: "shoe"
- Category dropdown shows: selected category (if any)
- Price fields show: entered values (if any)
- Sort shows: selected option (if any)
- URL contains all parameters

## Responsive Design

- Works on Desktop, Tablet, and Mobile
- Product grid adjusts based on screen size
- Filter section responsive on small screens

## Important Notes

- Image URLs are from Unsplash (free stock photos)
- Placeholder images used if no image URL provided
- Stock status shows different colors (green = available, orange = limited)
- Rating shown with star emoji
- All prices are in Pakistani Rupees (Rs.)

## Troubleshooting

1. **"Cannot find module"**: Run `npm install` again
2. **MongoDB connection error**: Check if MongoDB is running
3. **Page shows blank products**: Run `npm run seed`
4. **CSS not loading**: Make sure server.js has `app.use(express.static('public'))`

## Summary

This project demonstrates:
- MongoDB database design
- Express routing with query parameters
- Pagination logic
- Filter implementation
- Search functionality
- Sorting mechanisms
- EJS templating
- Bootstrap responsive design
