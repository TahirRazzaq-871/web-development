# Quick Reference - Assignment 3

## 🚀 Quick Start Commands

```bash
# Step 1: Install dependencies
npm install

# Step 2: Seed database with 25 products
npm run seed

# Step 3: Start server
npm start
```

## 🌐 URLs to Test

**Main Page:**
- http://localhost:3000
- http://localhost:3000/products

**Search Examples:**
- http://localhost:3000/products?search=phone
- http://localhost:3000/products?search=shoe
- http://localhost:3000/products?search=electronics

**Category Filter:**
- http://localhost:3000/products?category=Electronics
- http://localhost:3000/products?category=Fashion
- http://localhost:3000/products?category=Shoes
- http://localhost:3000/products?category=Home
- http://localhost:3000/products?category=Books

**Price Filter:**
- http://localhost:3000/products?minPrice=500&maxPrice=2000
- http://localhost:3000/products?minPrice=1000&maxPrice=5000

**Sorting:**
- http://localhost:3000/products?sort=price_asc
- http://localhost:3000/products?sort=price_desc
- http://localhost:3000/products?sort=rating_desc

**Pagination:**
- http://localhost:3000/products?page=1
- http://localhost:3000/products?page=2
- http://localhost:3000/products?page=3

**Combined (All Filters):**
- http://localhost:3000/products?page=1&search=shoe&category=Shoes&minPrice=1000&maxPrice=3000&sort=rating_desc

## 📁 File Locations

| File | Location | Purpose |
|------|----------|---------|
| Server | `server.js` | Express server setup |
| Products Route | `routes/products.js` | Filtering logic |
| Product Model | `models/Product.js` | MongoDB schema |
| Product List Template | `views/products.ejs` | HTML template |
| Seed Script | `seed.js` | Add sample products |
| Config | `.env` | Database & port |

## 🗄️ Collections in MongoDB

After running `npm run seed`, MongoDB has:
- **Database**: `ecommerce`
- **Collection**: `products`
- **Documents**: 25 sample products

## 📊 Database Query Examples

```javascript
// Find all products
db.products.find()

// Find by category
db.products.find({ category: "Electronics" })

// Find by price range
db.products.find({ price: { $gte: 1000, $lte: 5000 } })

// Find by name (search)
db.products.find({ name: /phone/i })

// Count products
db.products.countDocuments()
```

## 🔑 Key Code Locations

**Pagination Logic** → `routes/products.js` line 39-49
**Search Logic** → `routes/products.js` line 18-20
**Category Filter** → `routes/products.js` line 23-25
**Price Filter** → `routes/products.js` line 28
**Sorting** → `routes/products.js` line 30-37
**Filter Form** → `views/products.ejs` line 150-190
**Product Card** → `views/products.ejs` line 210-250
**Pagination Buttons** → `views/products.ejs` line 255-280

## 📝 Environment Variables (.env)

```
MONGODB_URI=mongodb://localhost:27017/ecommerce
PORT=3000
```

**For MongoDB Atlas (Cloud):**
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/ecommerce
PORT=3000
```

## ✅ Testing Checklist

- [ ] All dependencies installed (`npm install`)
- [ ] MongoDB running (local or Atlas connection)
- [ ] Database seeded (`npm run seed`)
- [ ] Server started (`npm start`)
- [ ] Main page loads: http://localhost:3000
- [ ] Search works: http://localhost:3000/products?search=phone
- [ ] Category filter works: http://localhost:3000/products?category=Electronics
- [ ] Price filter works: http://localhost:3000/products?minPrice=1000&maxPrice=5000
- [ ] Sorting works: http://localhost:3000/products?sort=price_asc
- [ ] Pagination works: Next/Previous buttons work
- [ ] Filters persist: When clicking next page, filters stay active
- [ ] No products message: Shows when filters return no results

## 🎨 UI Features

- ✅ Bootstrap responsive grid
- ✅ Product cards with image, name, price, category, rating, stock
- ✅ Filter section at top
- ✅ Search bar
- ✅ Category dropdown
- ✅ Min/Max price inputs
- ✅ Sort dropdown
- ✅ Pagination buttons
- ✅ Page counter (Page 1 of 5)
- ✅ Mobile responsive design

## 🛠️ If Something Breaks

1. **Port already in use**: Change PORT in .env, restart server
2. **MongoDB not found**: Check connection string in .env
3. **No products showing**: Run `npm run seed` again
4. **Module not found**: Run `npm install` again
5. **CSS looks weird**: Restart server and clear browser cache

## 📞 Important Files to Keep

These are the **core backend files** you MUST keep:
- ✅ `server.js` - Server entry point
- ✅ `routes/products.js` - All filtering logic
- ✅ `models/Product.js` - Database schema
- ✅ `views/products.ejs` - Product page
- ✅ `seed.js` - Database seeding
- ✅ `package.json` - Dependencies

**These can be deleted (old frontend):**
- ❌ `index.html` - Old homepage
- ❌ `script.js` - Old scripts
- ❌ `style.css` - Old styles

## 🎓 Interview Topics

If asked during demo/viva, explain:

1. **How pagination works**: `skip = (page-1) * 8`, show 8 per page
2. **How search works**: Use MongoDB regex `$regex` with `$options: 'i'`
3. **How filters work**: Build filter object, apply to MongoDB query
4. **How sorting works**: Pass sort object to MongoDB `sort()` method
5. **How persistence works**: Pass all filters in query string to next page

## 📚 Additional Resources

- MongoDB Docs: https://docs.mongodb.com/manual/
- Express Docs: https://expressjs.com/
- EJS Docs: https://ejs.co/
- Bootstrap Docs: https://getbootstrap.com/

---

**Ready to Demo?** Follow the Quick Start Commands above and you're good to go! 🎉
