# Lab Assignment 3: Authentication & Role-Based Access Control - Implementation Guide

## 📋 Overview

This document outlines the complete implementation of Lab Assignment 3, which adds User Authentication and Role-Based Access Control (RBAC) to the existing e-commerce platform.

---

## 🔧 Quick Start

### 1. Install Dependencies (Already Done)
All required packages have been added to `package.json`:
- `bcryptjs` - Password hashing
- `express-session` - Session management
- `connect-mongo` - MongoDB session store
- `connect-flash` - Flash messages

### 2. Seed the Database
Run the seed script to populate products and create default users:
```bash
npm run seed
```

**Default Users Created:**
- **Admin:** `admin@example.com` / `admin123`
- **Customer:** `customer@example.com` / `customer123`

### 3. Start the Server
```bash
npm start
```

The server runs on `http://localhost:3000`

---

## 📁 Project Structure

### New Files Created:

```
models/
├── User.js                    # User schema with bcryptjs hashing
├── Product.js                 # (Existing)

middleware/
├── auth.js                    # Auth middleware (isLoggedIn, isAdmin, isLoggedOut)
├── upload.js                  # (Existing)

routes/
├── authRoutes.js              # Authentication routes (register, login, logout)
├── products.js                # (Existing - Product listing)
├── adminRoutes.js             # (Modified - Now protected with isAdmin)

views/
├── navbar.ejs                 # Dynamic navbar component
├── register.ejs               # Registration form
├── login.ejs                  # Login form
├── products.ejs               # (Modified - Includes navbar & flash messages)
├── admin/
│   ├── dashboard.ejs          # (Modified - Protected, logout button)
│   ├── add-product.ejs        # (Modified - Protected, logout button)
│   └── edit-product.ejs       # (Modified - Protected, logout button)
```

---

## 🔐 Key Features Implemented

### 1. User Model (`models/User.js`)

**Fields:**
- `name` (String) - User's full name
- `email` (String) - Unique email address
- `password` (String) - Hashed password
- `role` (String) - 'customer' or 'admin'
- `createdAt` (Date) - Account creation timestamp

**Security Features:**
- Passwords automatically hashed using bcryptjs before saving
- Password comparison method included for login verification
- Passwords not returned by default in queries

### 2. Authentication Routes (`routes/authRoutes.js`)

#### GET `/register`
- Displays registration form
- Redirects to `/products` if already logged in

#### POST `/register`
Validates:
- All fields are required
- Password minimum 6 characters
- Passwords match
- Email is unique

#### GET `/login`
- Displays login form
- Redirects to `/products` if already logged in

#### POST `/login`
- Validates email and password
- Compares password using bcrypt
- Creates session on successful login
- Shows flash messages for errors

#### GET `/logout`
- Destroys session
- Shows success message
- Redirects to products page

### 3. Auth Middleware (`middleware/auth.js`)

#### `isLoggedIn`
- Protects routes requiring authentication
- Redirects to `/login` if not logged in
- Shows flash message

#### `isAdmin`
- Checks if user is logged in AND has admin role
- Protects all `/admin` routes
- Redirects unauthorized users to products page with error message

#### `isLoggedOut`
- Prevents logged-in users from accessing login/register pages
- Redirects to `/products` if already logged in

### 4. Session Management

**Configuration (server.js):**
```javascript
- Session storage: MongoDB (connect-mongo)
- Session timeout: 24 hours
- Cookie httpOnly: true (secure)
- Session secret: configurable via .env
```

Sessions persist across:
- Page refreshes
- Browser navigation
- Server restarts (stored in MongoDB)

### 5. Dynamic Navbar (`views/navbar.ejs`)

**If NOT logged in:**
- Shows: Login button
- Shows: Register button

**If logged in:**
- Shows: User's name
- Shows: Logout button
- Shows: Admin Panel link (only if admin)

**Responsive Design:**
- Mobile hamburger menu
- Adaptive layout for all screen sizes

### 6. Role-Based Access Control

**Customer Role (Default):**
- Can browse products
- Can search and filter
- Cannot access admin panel

**Admin Role:**
- Full access to admin dashboard
- Can add/edit/delete products
- Protected by `isAdmin` middleware

---

## 🚀 User Flow

### Registration Flow:
1. User visits `/register`
2. Fills registration form with name, email, password
3. Server validates data
4. If valid → Password hashed → User saved to MongoDB
5. Redirect to login page with success message
6. User can now login

### Login Flow:
1. User visits `/login`
2. Enters email and password
3. Server finds user by email
4. Compares password with stored hash
5. If valid → Session created → Redirects to products
6. Navbar updates to show user name and logout button

### Admin Access Flow:
1. Admin logs in with admin account
2. User role = 'admin' stored in session
3. Admin can visit `/admin` routes
4. `isAdmin` middleware checks role
5. If not admin → Shows error message and redirects
6. All admin actions (add/edit/delete) now protected

### Logout Flow:
1. User clicks logout button
2. Session destroyed
3. Redirects to products page
4. Navbar reverts to showing Login/Register

---

## 🔒 Security Features

### Password Security:
- All passwords hashed with bcryptjs (10 salt rounds)
- Plaintext passwords never stored
- Password comparison uses bcrypt.compare()
- Passwords not returned in API responses

### Session Security:
- Sessions stored in MongoDB (not in memory)
- httpOnly cookies prevent XSS attacks
- Session timeout: 24 hours
- Secure flag for HTTPS (can be enabled)

### Access Control:
- Admin routes protected by middleware
- Non-admin users cannot access `/admin`
- Unauthorized access shows error message
- Session required for protected routes

### Flash Messages:
- Success messages for registration/login
- Error messages for validation failures
- Error messages for unauthorized access
- Messages auto-dismiss

---

## 📝 Flash Messages

### Success Messages:
- "Registration successful! Please log in."
- "Welcome back, [Name]!"
- "Logged out successfully"
- "Product added successfully"

### Error Messages:
- "All fields are required"
- "Password must be at least 6 characters"
- "Passwords do not match"
- "Email already registered"
- "Invalid email or password"
- "Access Denied! Only administrators can access this page."
- "Please log in to continue"

---

## 🧪 Testing the System

### Test Registration:
1. Go to `http://localhost:3000/register`
2. Fill form with:
   - Name: Test User
   - Email: test@example.com
   - Password: test123
   - Confirm Password: test123
3. Click Register
4. Should redirect to login with success message

### Test Login:
1. Go to `http://localhost:3000/login`
2. Login with: `customer@example.com` / `customer123`
3. Navbar should show name and logout button
4. Try accessing `/admin` → Should show error and redirect

### Test Admin Access:
1. Login with: `admin@example.com` / `admin123`
2. Navbar should show "Admin Panel" link
3. Click admin panel → Full access to dashboard
4. Can add/edit/delete products

### Test Session Persistence:
1. Login to customer account
2. Refresh page → Still logged in
3. Close browser → Session stored in MongoDB
4. Open new tab and go to site → Still logged in (24h window)

### Test Logout:
1. Click Logout button
2. Navbar reverts to Login/Register
3. Cannot access `/admin`

---

## 📊 Database Schema

### User Collection:
```javascript
{
  _id: ObjectId,
  name: "John Doe",
  email: "john@example.com",
  password: "$2a$10$...", // Hashed
  role: "customer",       // or "admin"
  createdAt: ISODate("2024-01-01T00:00:00.000Z")
}
```

### Sessions Collection:
```javascript
{
  _id: "session_id_...",
  session: {
    user: {
      id: ObjectId,
      name: "John",
      email: "john@example.com",
      role: "customer"
    }
  },
  expires: ISODate("2024-01-02T00:00:00.000Z")
}
```

---

## ⚠️ Important Notes

### Environment Variables:
```env
MONGODB_URI=mongodb://localhost:27017/ecommerce
PORT=3000
SESSION_SECRET=your-secret-key-change-in-production
```

### Default Users (from seed):
- Admin: `admin@example.com` / `admin123`
- Customer: `customer@example.com` / `customer123`

**⚠️ IMPORTANT:** Change the passwords in production!

### Session Store:
- Sessions stored in MongoDB collection: `sessions`
- Sessions expire after 24 hours
- Automatic cleanup of expired sessions

### Customization:
To modify session timeout, edit `server.js`:
```javascript
maxAge: 24 * 60 * 60 * 1000  // 24 hours (in milliseconds)
```

---

## 🎯 Endpoints Summary

### Public Routes:
- `GET /` → Redirects to `/products`
- `GET /products` → Product listing (with filters)
- `GET /register` → Registration form
- `POST /register` → Register new user
- `GET /login` → Login form
- `POST /login` → Authenticate user

### Protected Routes (Login Required):
- `GET /logout` → Destroy session

### Admin Routes (Admin Role Required):
- `GET /admin` → Dashboard
- `GET /admin/add-product` → Add product form
- `POST /admin/add-product` → Create product
- `GET /admin/edit/:id` → Edit product form
- `POST /admin/edit/:id` → Update product
- `GET /admin/delete/:id` → Delete product

---

## 🎓 Viva/Demo Talking Points

1. **Password Security**: Explain bcryptjs hashing process
2. **Session Management**: Describe session persistence in MongoDB
3. **Middleware Pattern**: How `isAdmin` and `isLoggedIn` protect routes
4. **Role-Based Access**: Difference between customer and admin roles
5. **Flash Messages**: User feedback for all actions
6. **Database Seeding**: How admin users are created
7. **Security Features**: httpOnly cookies, password comparison
8. **Dynamic UI**: Navbar changes based on login state

---

## 📞 Troubleshooting

### "Cannot find module 'bcryptjs'":
```bash
npm install
```

### Sessions not persisting:
- Check MongoDB connection
- Verify `connect-mongo` is installed
- Check `sessions` collection exists in database

### Cannot login:
- Verify correct email/password
- Check User collection has documents
- Run `npm run seed` to create default users

### Admin routes not accessible:
- Verify logged in with admin account
- Check `user.role === 'admin'` in session
- Review `isAdmin` middleware

---

**Implementation Status:** ✅ Complete

All features have been implemented according to Lab Assignment 3 requirements.
