const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { isLoggedIn, isLoggedOut } = require('../middleware/auth');

// REGISTER PAGE - GET
router.get('/register', isLoggedOut, (req, res) => {
  res.render('register', { errors: [] });
});

// REGISTER - POST
router.post('/register', isLoggedOut, async (req, res) => {
  try {
    const { name, email, password, confirmPassword } = req.body;
    const errors = [];

    // Validation
    if (!name || !email || !password || !confirmPassword) {
      errors.push('All fields are required');
    }

    if (password.length < 6) {
      errors.push('Password must be at least 6 characters');
    }

    if (password !== confirmPassword) {
      errors.push('Passwords do not match');
    }

    // Check if email already exists
    if (errors.length === 0) {
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        errors.push('Email already registered');
      }
    }

    if (errors.length > 0) {
      return res.render('register', {
        errors,
        name,
        email
      });
    }

    // Create new user
    const newUser = new User({
      name,
      email,
      password
    });

    await newUser.save();
    req.flash('success_msg', 'Registration successful! Please log in.');
    res.redirect('/login');

  } catch (error) {
    console.error('Registration error:', error);
    res.render('register', {
      errors: ['An error occurred during registration'],
      name: req.body.name,
      email: req.body.email
    });
  }
});

// LOGIN PAGE - GET
router.get('/login', isLoggedOut, (req, res) => {
  res.render('login', { errors: [] });
});

// LOGIN - POST
router.post('/login', isLoggedOut, async (req, res) => {
  try {
    const { email, password } = req.body;
    const errors = [];

    // Validation
    if (!email || !password) {
      errors.push('Email and password are required');
    }

    if (errors.length > 0) {
      return res.render('login', { errors, email });
    }

    // Find user by email (need to select password explicitly)
    const user = await User.findOne({ email }).select('+password');

    if (!user) {
      errors.push('Invalid email or password');
      return res.render('login', { errors, email });
    }

    // Compare password
    const isPasswordValid = await user.comparePassword(password);

    if (!isPasswordValid) {
      errors.push('Invalid email or password');
      return res.render('login', { errors, email });
    }

    // Create session
    req.session.user = {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role
    };

    req.flash('success_msg', `Welcome back, ${user.name}!`);
    res.redirect('/products');

  } catch (error) {
    console.error('Login error:', error);
    res.render('login', {
      errors: ['An error occurred during login'],
      email: req.body.email
    });
  }
});

// LOGOUT
router.get('/logout', isLoggedIn, (req, res) => {
  req.flash('success_msg', 'Logged out successfully');
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
    }
    res.redirect('/login');
  });
});

module.exports = router;
