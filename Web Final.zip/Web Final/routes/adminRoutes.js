const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const upload = require('../middleware/upload');
const { isAdmin } = require('../middleware/auth');
const fs = require('fs');
const path = require('path');

// DASHBOARD - Show all products (Protected by isAdmin)
router.get('/admin', isAdmin, async (req, res) => {
  try {
    const products = await Product.find().sort({ _id: -1 });
    const totalProducts = await Product.countDocuments();

    res.render('admin/dashboard', {
      products,
      totalProducts,
      message: req.query.message || null,
      user: req.session.user
    });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error loading admin dashboard');
  }
});

// ADD PRODUCT - GET form (Protected by isAdmin)
router.get('/admin/add-product', isAdmin, (req, res) => {
  res.render('admin/add-product', { errors: null, user: req.session.user });
});

// ADD PRODUCT - POST create (Protected by isAdmin)
router.post('/admin/add-product', isAdmin, upload.single('image'), async (req, res) => {
  try {
    const { name, price, category, rating, stock } = req.body;
    const errors = [];

    // Validation
    if (!name || name.trim() === '') errors.push('Product name is required');
    if (!price || price <= 0) errors.push('Valid price is required');
    if (!category || category.trim() === '') errors.push('Category is required');
    if (rating !== undefined && (rating < 0 || rating > 5)) errors.push('Rating must be between 0-5');
    if (!stock || stock < 0) errors.push('Valid stock is required');

    if (errors.length > 0) {
      // Delete uploaded file if validation fails
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      return res.render('admin/add-product', { errors });
    }

    // Create image path
    let imagePath = 'https://via.placeholder.com/300x300?text=Product+Image';
    if (req.file) {
      imagePath = `/uploads/${req.file.filename}`;
    }

    // Create new product
    const newProduct = new Product({
      name: name.trim(),
      price: parseFloat(price),
      category: category.trim(),
      rating: parseFloat(rating) || 0,
      stock: parseInt(stock),
      image: imagePath
    });

    await newProduct.save();
    res.redirect('/admin?message=Product added successfully');
  } catch (error) {
    console.error(error);
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).send('Error adding product');
  }
});

// EDIT PRODUCT - GET form (Protected by isAdmin)
router.get('/admin/edit/:id', isAdmin, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).send('Product not found');
    }

    res.render('admin/edit-product', { product, errors: null });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error loading product');
  }
});

// EDIT PRODUCT - POST update (Protected by isAdmin)
router.post('/admin/edit/:id', isAdmin, upload.single('image'), async (req, res) => {
  try {
    const { name, price, category, rating, stock } = req.body;
    const errors = [];

    // Validation
    if (!name || name.trim() === '') errors.push('Product name is required');
    if (!price || price <= 0) errors.push('Valid price is required');
    if (!category || category.trim() === '') errors.push('Category is required');
    if (rating !== undefined && (rating < 0 || rating > 5)) errors.push('Rating must be between 0-5');
    if (!stock || stock < 0) errors.push('Valid stock is required');

    const product = await Product.findById(req.params.id);
    if (!product) {
      if (req.file) fs.unlinkSync(req.file.path);
      return res.status(404).send('Product not found');
    }

    if (errors.length > 0) {
      if (req.file) {
        fs.unlinkSync(req.file.path);
      }
      return res.render('admin/edit-product', { product, errors });
    }

    // Handle image update
    if (req.file) {
      // Delete old image if it's not a placeholder
      if (product.image && product.image.includes('/uploads/')) {
        const oldImagePath = path.join(__dirname, '../public', product.image);
        if (fs.existsSync(oldImagePath)) {
          fs.unlinkSync(oldImagePath);
        }
      }
      product.image = `/uploads/${req.file.filename}`;
    }

    // Update product
    product.name = name.trim();
    product.price = parseFloat(price);
    product.category = category.trim();
    product.rating = parseFloat(rating) || 0;
    product.stock = parseInt(stock);

    await product.save();
    res.redirect('/admin?message=Product updated successfully');
  } catch (error) {
    console.error(error);
    if (req.file) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).send('Error updating product');
  }
});

// DELETE PRODUCT (Protected by isAdmin)
router.get('/admin/delete/:id', isAdmin, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    // Delete image file if it exists
    if (product.image && product.image.includes('/uploads/')) {
      const imagePath = path.join(__dirname, '../public', product.image);
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
      }
    }

    await Product.findByIdAndDelete(req.params.id);
    res.redirect('/admin?message=Product deleted successfully');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error deleting product');
  }
});

module.exports = router;
