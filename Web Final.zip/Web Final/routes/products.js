const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

router.get('/products', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const search = req.query.search || '';
    const category = req.query.category || '';
    const minPrice = req.query.minPrice ? parseInt(req.query.minPrice) : 0;
    const maxPrice = req.query.maxPrice ? parseInt(req.query.maxPrice) : 999999;
    const sort = req.query.sort || 'default';

    let filter = {};

    if (search) {
      filter.name = { $regex: search, $options: 'i' };
    }

    if (category) {
      filter.category = category;
    }

    filter.price = { $gte: minPrice, $lte: maxPrice };

    let sortOption = {};
    if (sort === 'price_asc') {
      sortOption = { price: 1 };
    } else if (sort === 'price_desc') {
      sortOption = { price: -1 };
    } else if (sort === 'rating_desc') {
      sortOption = { rating: -1 };
    }

    const itemsPerPage = 8;
    const skip = (page - 1) * itemsPerPage;

    const products = await Product.find(filter)
      .sort(sortOption)
      .skip(skip)
      .limit(itemsPerPage);

    const totalProducts = await Product.countDocuments(filter);
    const totalPages = Math.ceil(totalProducts / itemsPerPage);

    const categories = await Product.distinct('category');

    res.render('products', {
      products,
      page,
      totalPages,
      search,
      category,
      minPrice,
      maxPrice,
      sort,
      categories
    });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error fetching products');
  }
});

module.exports = router;
