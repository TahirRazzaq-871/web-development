$(document).ready(function () {

  // ===== Hamburger Menu Toggle =====
  $('#hamburgerBtn').on('click', function () {
    $('#navMenu').toggleClass('nav-open');
    $(this).toggleClass('is-open');
  });


  // ===== Slider Initialization =====
  var $slider = $('.products-slider');
  var totalSlides = $slider.find('.product-card').length;

  // ===== Counter Update =====
  function updateCounter(slick) {
    var current = slick.currentSlide + 1;
    $('#slideCounter').text('Showing ' + current + ' of ' + totalSlides);
  }

  // Bind 'init' BEFORE calling .slick() so it fires on setup
  $slider.on('init', function (event, slick) {
    updateCounter(slick);
  });

  // Update counter after every slide change
  $slider.on('afterChange', function (event, slick) {
    updateCounter(slick);
  });

  $slider.slick({
    infinite: true,
    speed: 450,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    arrows: false,
    dots: false,
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 2 }
      },
      {
        breakpoint: 600,
        settings: { slidesToShow: 1 }
      }
    ]
  });


  // ===== Navigation Controls =====
  $('#prevBtn').on('click', function () {
    $slider.slick('slickPrev');
  });

  $('#nextBtn').on('click', function () {
    $slider.slick('slickNext');
  });


  // ===== Autoplay Pause on Hover =====
  $slider.on('mouseenter', '.product-card', function () {
    $slider.slick('slickPause');
  });

  $slider.on('mouseleave', '.product-card', function () {
    $slider.slick('slickPlay');
  });

});
