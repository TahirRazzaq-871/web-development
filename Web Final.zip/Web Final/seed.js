const mongoose = require('mongoose');
require('dotenv').config();

const Product = require('./models/Product');
const User = require('./models/User');

const sampleProducts = [
  // Running Shoes (5 products) - Official Unsplash running shoe images
  {
    name: 'Nike Air Max Pro',
    price: 4500,
    category: 'Running Shoes',
    rating: 4.8,
    stock: 25,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    description: 'Professional running shoes with air cushioning'
  },
  {
    name: 'Adidas Ultraboost Elite',
    price: 5200,
    category: 'Running Shoes',
    rating: 4.7,
    stock: 18,
    image: 'https://images.unsplash.com/photo-1528701800489-20be3c1ea6b9?w=400&h=400&fit=crop',
    description: 'High performance marathon running shoes'
  },
  {
    name: 'Puma Sprint Running',
    price: 3800,
    category: 'Running Shoes',
    rating: 4.6,
    stock: 22,
    image: 'https://images.unsplash.com/photo-1556906781-9a412961c28c?w=400&h=400&fit=crop',
    description: 'Lightweight sprint training shoes'
  },
  {
    name: 'New Balance Running Elite',
    price: 4200,
    category: 'Running Shoes',
    rating: 4.5,
    stock: 20,
    image: 'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?w=400&h=400&fit=crop',
    description: 'Comfort-focused stability running shoes'
  },
  {
    name: 'ASICS Gel Runner Pro',
    price: 4800,
    category: 'Running Shoes',
    rating: 4.7,
    stock: 24,
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400&h=400&fit=crop',
    description: 'Professional gel-cushioned running shoes'
  },

  // Sneakers (5 products) - Modern street sneaker images
  {
    name: 'Classic White Sneakers',
    price: 2800,
    category: 'Sneakers',
    rating: 4.6,
    stock: 28,
    image: 'https://images.unsplash.com/photo-1520256862855-398228c41684?w=400&h=400&fit=crop',
    description: 'Premium white sneakers for street style'
  },
  {
    name: 'Urban Black Sneakers',
    price: 3200,
    category: 'Sneakers',
    rating: 4.7,
    stock: 25,
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop',
    description: 'Trendy black street sneakers'
  },
  {
    name: 'Retro Vintage Sneakers',
    price: 3600,
    category: 'Sneakers',
    rating: 4.5,
    stock: 23,
    image: 'https://images.unsplash.com/photo-1528701800489-20be3c1ea6b9?w=400&h=400&fit=crop',
    description: 'Classic retro fashion sneakers'
  },
  {
    name: 'Modern Fashion Sneakers',
    price: 4100,
    category: 'Sneakers',
    rating: 4.8,
    stock: 20,
    image: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=400&h=400&fit=crop',
    description: 'Contemporary designer sneakers'
  },
  {
    name: 'Canvas Street Sneakers',
    price: 1900,
    category: 'Sneakers',
    rating: 4.4,
    stock: 30,
    image: 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=400&h=400&fit=crop',
    description: 'Comfortable everyday canvas sneakers'
  },

  // Formal Shoes (5 products) - Leather formal shoe images
  {
    name: 'Classic Leather Oxfords',
    price: 5000,
    category: 'Formal Shoes',
    rating: 4.7,
    stock: 22,
    image: 'https://images.unsplash.com/photo-1520975954732-35dd22299614?w=400&h=400&fit=crop',
    description: 'Elegant leather formal shoes for office'
  },
  {
    name: 'Oxford Business Shoes',
    price: 5500,
    category: 'Formal Shoes',
    rating: 4.8,
    stock: 18,
    image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400&h=400&fit=crop',
    description: 'Professional oxford shoes for business'
  },
  {
    name: 'Leather Derby Formal',
    price: 4800,
    category: 'Formal Shoes',
    rating: 4.6,
    stock: 20,
    image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=400&h=400&fit=crop',
    description: 'Premium leather derby formal shoes'
  },
  {
    name: 'Black Dress Shoes',
    price: 5200,
    category: 'Formal Shoes',
    rating: 4.7,
    stock: 21,
    image: 'https://images.unsplash.com/photo-1533867617858-e7b97e060509?w=400&h=400&fit=crop',
    description: 'Sophisticated black dress shoes'
  },
  {
    name: 'Italian Leather Formal',
    price: 6000,
    category: 'Formal Shoes',
    rating: 4.9,
    stock: 15,
    image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&h=400&fit=crop',
    description: 'Premium Italian leather formal shoes'
  },

  // Casual Shoes (5 products)
  {
    name: 'White Canvas Casual',
    price: 1600,
    category: 'Casual Shoes',
    rating: 4.5,
    stock: 35,
    image: 'https://images.unsplash.com/photo-1579324537058-4a73f0a3a8a0?w=400&h=400&fit=crop',
    description: 'Classic white canvas casual shoes'
  },
  {
    name: 'Slip-On Loafers',
    price: 2200,
    category: 'Casual Shoes',
    rating: 4.3,
    stock: 28,
    image: 'https://images.unsplash.com/photo-1549298881-f5b5d4e78cbf?w=400&h=400&fit=crop',
    description: 'Comfortable slip-on loafers'
  },
  {
    name: 'Brown Casual Wear',
    price: 2100,
    category: 'Casual Shoes',
    rating: 4.4,
    stock: 26,
    image: 'https://images.unsplash.com/photo-1606107557529-da4a970a8a2e?w=400&h=400&fit=crop',
    description: 'Versatile brown casual shoes'
  },
  {
    name: 'Denim Casual Wear',
    price: 1950,
    category: 'Casual Shoes',
    rating: 4.4,
    stock: 32,
    image: 'https://images.unsplash.com/photo-1560343676-04071c5f467b?w=400&h=400&fit=crop',
    description: 'Trendy denim casual shoes'
  },
  {
    name: 'Everyday Comfort Shoes',
    price: 1700,
    category: 'Casual Shoes',
    rating: 4.3,
    stock: 30,
    image: 'https://images.unsplash.com/photo-1597872200969-2b65d56bd16b?w=400&h=400&fit=crop',
    description: 'Comfortable everyday casual shoes'
  },

  // Sports Shoes (5 products)
  {
    name: 'Basketball Court Shoes',
    price: 5500,
    category: 'Sports Shoes',
    rating: 4.8,
    stock: 20,
    image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400&h=400&fit=crop',
    description: 'Professional basketball shoes'
  },
  {
    name: 'Gym Training Shoes',
    price: 3800,
    category: 'Sports Shoes',
    rating: 4.5,
    stock: 24,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
    description: 'Durable gym training shoes'
  },
  {
    name: 'Athletic Sports Shoes',
    price: 4200,
    category: 'Sports Shoes',
    rating: 4.6,
    stock: 22,
    image: 'https://images.unsplash.com/photo-1517457373614-b7152f800fd1?w=400&h=400&fit=crop',
    description: 'Professional athletic sports shoes'
  },
  {
    name: 'Cross Training Shoes',
    price: 4500,
    category: 'Sports Shoes',
    rating: 4.6,
    stock: 22,
    image: 'https://images.unsplash.com/photo-1556906781-9a412961c28c?w=400&h=400&fit=crop',
    description: 'Versatile cross training shoes'
  },
  {
    name: 'Performance Sport Shoes',
    price: 3500,
    category: 'Sports Shoes',
    rating: 4.5,
    stock: 25,
    image: 'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?w=400&h=400&fit=crop',
    description: 'High-performance sports shoes'
  },

  // Sandals (5 products) - STRICT: Open sandals/slippers ONLY
  {
    name: 'Leather Sandals',
    price: 1800,
    category: 'Sandals',
    rating: 4.4,
    stock: 32,
    image: 'https://images.unsplash.com/photo-1593032465171-bc9d7f0a4d6a?w=400&h=400&fit=crop',
    description: 'Comfortable leather sandals for summer'
  },
  {
    name: 'Beach Flip Flops',
    price: 800,
    category: 'Sandals',
    rating: 4.3,
    stock: 50,
    image: 'https://images.unsplash.com/photo-1588099768531-a72d4a198538?w=400&h=400&fit=crop',
    description: 'Casual beach flip flops'
  },
  {
    name: 'Sports Sandals',
    price: 2200,
    category: 'Sandals',
    rating: 4.5,
    stock: 28,
    image: 'https://images.unsplash.com/photo-1622920797163-7b1c3c0f0d5c?w=400&h=400&fit=crop',
    description: 'Durable sports sandals with grip'
  },
  {
    name: 'Orthopedic Sandals',
    price: 2800,
    category: 'Sandals',
    rating: 4.7,
    stock: 22,
    image: 'https://images.unsplash.com/photo-1602810318028-4a2a9d8b3f4c?w=400&h=400&fit=crop',
    description: 'Comfortable orthopedic sandals'
  },
  {
    name: 'Fashion Sandals',
    price: 1500,
    category: 'Sandals',
    rating: 4.4,
    stock: 35,
    image: 'https://images.unsplash.com/photo-1612810436541-336d0b9f3c4b?w=400&h=400&fit=crop',
    description: 'Stylish fashion sandals'
  }
];

async function seedDatabase() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/ecommerce');
    console.log('Connected to MongoDB');

    // Seed Products
    await Product.deleteMany({});
    console.log('Old products deleted');

    await Product.insertMany(sampleProducts);
    console.log(`Database seeded with ${sampleProducts.length} products`);

    // Seed Admin User
    await User.deleteMany({});
    console.log('Old users deleted');

    const adminUser = new User({
      name: 'Admin User',
      email: 'admin@example.com',
      password: 'admin123', // This will be hashed by User model pre-save hook
      role: 'admin'
    });

    await adminUser.save();
    console.log('Admin user created: admin@example.com (password: admin123)');

    // Create a sample customer user
    const customerUser = new User({
      name: 'John Doe',
      email: 'customer@example.com',
      password: 'customer123', // This will be hashed by User model pre-save hook
      role: 'customer'
    });

    await customerUser.save();
    console.log('Sample customer user created: customer@example.com (password: customer123)');

    await mongoose.connection.close();
    console.log('Database connection closed');
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
}

seedDatabase();
