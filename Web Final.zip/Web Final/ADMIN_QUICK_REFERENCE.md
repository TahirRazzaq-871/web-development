# Quick Start Guide - Admin Panel

## File Structure Created

✅ **Middleware**
- `middleware/upload.js` - Multer file upload configuration

✅ **Routes**
- `routes/adminRoutes.js` - All admin CRUD operations

✅ **Views (Admin)**
- `views/admin/dashboard.ejs` - Product list & stats
- `views/admin/add-product.ejs` - Create product form
- `views/admin/edit-product.ejs` - Edit product form

✅ **Directory**
- `public/uploads/` - Image storage folder

✅ **Updated Files**
- `package.json` - Added multer dependency
- `server.js` - Added admin routes import

---

## Test These URLs

### 1. Admin Dashboard
```
http://localhost:3000/admin?admin=true
```
Shows:
- Total products count
- Table with all products
- Edit/Delete buttons for each
- Add New Product button

### 2. Add Product Page
```
http://localhost:3000/admin/add-product?admin=true
```
Test:
- Fill form with product details
- Upload an image (drag & drop works)
- Submit form
- Should redirect to dashboard with success message

### 3. Edit Product Page
```
http://localhost:3000/admin/edit/{productId}?admin=true
```
Replace `{productId}` with an actual MongoDB ID
Test:
- Form pre-fills with existing data
- Can change any field
- Can upload new image
- Updates in database

### 4. Delete Product
From dashboard:
- Click Delete button on any product
- Confirm in popup
- Product removed from DB
- Image file deleted from disk

### 5. Image Upload
Test in Add or Edit form:
- Drag & drop image
- Or click to select
- Preview shows before submit
- After upload, check `/public/uploads/` folder

---

## Features to Verify

### ✅ Dashboard
- [ ] Shows total product count
- [ ] Displays all products in table
- [ ] Shows product images
- [ ] Shows Edit and Delete buttons
- [ ] Can navigate to add product page

### ✅ Add Product
- [ ] All form fields present (name, price, category, rating, stock)
- [ ] Image upload works
- [ ] Validation rejects empty fields
- [ ] Success message appears after add
- [ ] New product appears in dashboard

### ✅ Edit Product
- [ ] Form pre-fills with existing data
- [ ] Can update each field
- [ ] Can replace image
- [ ] Success message appears
- [ ] Changes reflected in dashboard

### ✅ Delete Product
- [ ] Confirmation popup appears
- [ ] Cancel doesn't delete
- [ ] Confirm removes product
- [ ] Product gone from dashboard
- [ ] Image file deleted from disk

### ✅ Image Upload
- [ ] Accepts JPG, PNG, GIF, WebP
- [ ] Rejects other formats
- [ ] Max 5MB size limit works
- [ ] Files stored in `/public/uploads/`
- [ ] Images display in dashboard

### ✅ Validation
- [ ] Empty name shows error
- [ ] Invalid price shows error
- [ ] Invalid stock shows error
- [ ] Rating outside 0-5 shows error
- [ ] Errors don't save product

---

## Environment Setup

### Option 1: Temporary Admin Access (URL parameter)
Just add `?admin=true` to any admin URL

### Option 2: Permanent Admin Access (Environment Variable)
Create/Edit `.env`:
```
ADMIN_MODE=true
```

### Option 3: MongoDB Connection
Update `.env`:
```
MONGODB_URI=mongodb://localhost:27017/ecommerce
```

---

## Common Issues & Solutions

### Issue: Images not showing
- **Solution**: Check file exists in `/public/uploads/`
- Verify path format is `/uploads/filename.ext`

### Issue: Admin routes 404
- **Solution**: Add `?admin=true` to URL
- Or set `ADMIN_MODE=true` in .env

### Issue: Upload fails
- **Solution**: Check file size < 5MB
- File must be image format (JPG, PNG, GIF, WebP)

### Issue: MongoDB error
- **Solution**: Start MongoDB service
- Check MONGODB_URI in .env

---

## Code Architecture

### Multer Configuration
```
middleware/upload.js
├── Storage destination: /public/uploads
├── Filename: timestamp-originalname.ext
├── File filter: image files only
└── Size limit: 5MB
```

### Admin Routes
```
routes/adminRoutes.js
├── GET /admin → Dashboard
├── GET /admin/add-product → Add form
├── POST /admin/add-product → Create
├── GET /admin/edit/:id → Edit form
├── POST /admin/edit/:id → Update
└── GET /admin/delete/:id → Delete
```

### Database
```
Product Model
├── name: String (required)
├── price: Number (required)
├── category: String (required)
├── rating: Number (0-5)
├── stock: Number (required)
└── image: String (file path)
```

---

## For Viva Presentation

### Key Points to Explain

1. **Admin Security**
   - Simple middleware checks admin flag
   - Can extend to proper JWT authentication
   - Query parameter `?admin=true` for testing

2. **Image Upload**
   - Multer stores images in `/public/uploads/`
   - Unique filenames prevent conflicts
   - Only image formats allowed
   - Files not stored in DB, just path

3. **CRUD Operations**
   - **Create**: Form validates, saves to MongoDB
   - **Read**: Dashboard shows all products
   - **Update**: Edit form with pre-filled data
   - **Delete**: Confirmation popup before delete

4. **Validation**
   - All required fields checked
   - Price must be positive
   - Stock must be non-negative
   - Rating limited to 0-5
   - Error messages display clearly

5. **User Experience**
   - Sidebar navigation
   - Bootstrap responsive design
   - Success/error messages
   - Image preview before upload
   - Drag-and-drop support

---

## Next Steps (If Needed)

1. Add proper user authentication (login/password)
2. Add more admin features (export, analytics)
3. Add product categories management
4. Add bulk operations
5. Add audit logging

---

**Status**: ✅ Complete and Ready for Testing
**Version**: 1.0
**Framework**: Express.js + EJS + MongoDB
**Last Updated**: 2026-05-18
