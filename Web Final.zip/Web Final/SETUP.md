# Assignment 3 - E-Commerce Project Setup Guide

## ✅ WHAT HAS BEEN CREATED

### New Backend Files:

| File | Purpose |
|------|---------|
| `server.js` | Main Express server - handles all requests |
| `seed.js` | Script to populate database with 25 sample products |
| `package.json` | Project dependencies and scripts |
| `.env` | Configuration file (database URI, port) |
| `.gitignore` | Files to ignore in version control |

### New Folders:

```
models/          → Product.js (MongoDB schema)
routes/          → products.js (all filtering/search/sort logic)
views/           → products.ejs (HTML template)
public/          → (for CSS, JS files - created for future use)
```

---

## 🚀 GETTING STARTED (Step by Step)

### Step 1: Open Terminal in Project Folder
```
cd "C:\Users\dell\Desktop\Assignment 3"
```

### Step 2: Install Dependencies
```
npm install
```
This installs:
- Express (web server)
- Mongoose (MongoDB connection)
- EJS (templating engine)
- dotenv (configuration)

⏱️ *Wait 2-3 minutes for installation*

### Step 3: Setup MongoDB

**OPTION A - Local MongoDB (Recommended for testing):**
1. Install MongoDB from https://www.mongodb.com/try/download/community
2. Start MongoDB service
3. `.env` file is already configured correctly

**OPTION B - MongoDB Atlas (Cloud - Free):**
1. Go to https://www.mongodb.com/cloud/atlas
2. Create free account → Create cluster → Get connection string
3. Update `.env` file:
```
MONGODB_URI=mongodb+srv://yourUsername:yourPassword@cluster0.xxxxx.mongodb.net/ecommerce
PORT=3000
```

### Step 4: Seed Database (Add 25 Products)
```
npm run seed
```
Output should show:
```
Connected to MongoDB
Old products deleted
Database seeded with 25 products
Database connection closed
```

### Step 5: Start Server
```
npm start
```
Output should show:
```
Connected to MongoDB
Server running on http://localhost:3000
```

### Step 6: Open in Browser
Go to: `http://localhost:3000`

---

## 📋 FILES TO CREATE/MODIFY - QUICK SUMMARY

### ✅ ALREADY CREATED:
- ✓ `server.js` - Express server
- ✓ `routes/products.js` - All filtering logic
- ✓ `models/Product.js` - Database schema
- ✓ `views/products.ejs` - Product page HTML
- ✓ `seed.js` - Sample products
- ✓ `package.json` - Dependencies
- ✓ `.env` - Configuration

### ❌ OLD FILES (Can be deleted or keep as reference):
- `index.html` (old homepage)
- `script.js` (old scripts)
- `style.css` (old styles - new styles in products.ejs)

---

## 🔍 HOW EACH FEATURE WORKS

### 1️⃣ SEARCH
**What it does:** Search products by name

**Example URLs:**
- `/products?search=phone`
- `/products?search=shoe`

**Code Location:** `routes/products.js` line 18-20
```javascript
if (search) {
  filter.name = { $regex: search, $options: 'i' };
}
```
Uses regex with case-insensitive flag (`i`)

---

### 2️⃣ CATEGORY FILTER
**What it does:** Filter by Electronics, Fashion, Shoes, Home, Books

**Example URLs:**
- `/products?category=Electronics`
- `/products?category=Fashion`

**Code Location:** `routes/products.js` line 23-25
```javascript
if (category) {
  filter.category = category;
}
```

---

### 3️⃣ PRICE FILTER
**What it does:** Filter between minimum and maximum prices

**Example URLs:**
- `/products?minPrice=1000&maxPrice=5000`
- `/products?minPrice=500&maxPrice=2000`

**Code Location:** `routes/products.js` line 28
```javascript
filter.price = { $gte: minPrice, $lte: maxPrice };
```

---

### 4️⃣ SORTING
**What it does:** Sort by price or rating

**Options:**
- `?sort=price_asc` → Low to High
- `?sort=price_desc` → High to Low
- `?sort=rating_desc` → Best Rated

**Code Location:** `routes/products.js` line 30-37
```javascript
if (sort === 'price_asc') {
  sortOption = { price: 1 };  // 1 = ascending
} else if (sort === 'price_desc') {
  sortOption = { price: -1 }; // -1 = descending
}
```

---

### 5️⃣ PAGINATION
**What it does:** Show 8 products per page

**Example URLs:**
- `/products?page=1` → Products 1-8
- `/products?page=2` → Products 9-16

**Code Location:** `routes/products.js` line 39-49
```javascript
const itemsPerPage = 8;
const skip = (page - 1) * itemsPerPage;  // Skip previous pages

const products = await Product.find(filter)
  .sort(sortOption)
  .skip(skip)        // Skip first N products
  .limit(itemsPerPage)  // Show only 8
```

**Skip Logic Explanation:**
```
Page 1: skip(0) → show items 1-8
Page 2: skip(8) → show items 9-16
Page 3: skip(16) → show items 17-24
```

---

### 6️⃣ FILTER PERSISTENCE
**What it does:** Keep filters active when changing pages

**Example:**
User searches for "shoe", filters by "Shoes" category, then clicks page 2:
```
/products?page=2&search=shoe&category=Shoes&sort=price_asc
```

**Code Location:** `views/products.ejs` - All pagination links include:
```html
?page=<%= page %>&search=<%= search %>&category=<%= category %>&minPrice=<%= minPrice %>&maxPrice=<%= maxPrice %>&sort=<%= sort %>
```

---

## 🗄️ DATABASE SCHEMA

**Product Model (MongoDB):**
```javascript
{
  _id: ObjectId,
  name: "Wireless Headphones",
  price: 2500,
  category: "Electronics",
  rating: 4.5,
  stock: 15,
  image: "https://...",
  description: "High quality headphones"
}
```

**Sample Products Included:**
- 6 Electronics
- 3 Fashion
- 4 Shoes
- 7 Home items
- 5 Books

---

## 🎨 UI FEATURES

**Product Card Shows:**
- ✓ Product image
- ✓ Product name
- ✓ Price in Rs.
- ✓ Category badge
- ✓ Rating (⭐ stars)
- ✓ Stock status (green/orange/red)

**Filter Section Shows:**
- ✓ Search box
- ✓ Category dropdown
- ✓ Min/Max price inputs
- ✓ Sort dropdown
- ✓ Search & Filter button
- ✓ Reset button

**Responsive:**
- ✓ Mobile (1 column)
- ✓ Tablet (2 columns)
- ✓ Desktop (4 columns)

---

## 📊 SAMPLE DATA

**Products by Category:**

**Electronics (6 items):**
- Wireless Headphones - Rs. 2500 ⭐4.5
- USB-C Cable - Rs. 400 ⭐4.0
- Phone Screen Protector - Rs. 300 ⭐4.2
- Smart Watch - Rs. 5000 ⭐4.7
- Portable Speaker - Rs. 1800 ⭐4.5
- Memory Card 64GB - Rs. 800 ⭐4.4

**Fashion (3 items):**
- Men Cotton T-Shirt - Rs. 800 ⭐4.3
- Women Denim Jeans - Rs. 2000 ⭐4.6
- Winter Jacket - Rs. 3500 ⭐4.4

**Shoes (4 items):**
- Sports Running Shoes - Rs. 3000 ⭐4.8
- Casual Sneakers - Rs. 1800 ⭐4.5
- Formal Shoes - Rs. 2500 ⭐4.3
- Kids Running Shoes - Rs. 1500 ⭐4.4

**Home (7 items):**
- Coffee Maker, Table Lamp, Bed Sheet, Knife Set, Microwave, Blender, Wall Clock

**Books (5 items):**
- The Great Gatsby, Python Programming, Web Design Guide, Database Design, Web Development

---

## ⚡ QUICK TEST SCENARIOS

**Test 1: Search**
1. Go to: `http://localhost:3000`
2. Type "phone" in search box
3. Click "Search & Filter"
4. ✓ Should show: Wireless Headphones, Phone Screen Protector, Portable Speaker

**Test 2: Category Filter**
1. Select "Shoes" from dropdown
2. Click "Search & Filter"
3. ✓ Should show: 4 shoe products

**Test 3: Price Filter**
1. Enter Min Price: 1000
2. Enter Max Price: 2500
3. Click "Search & Filter"
4. ✓ Should show: Products between Rs. 1000-2500

**Test 4: Sort**
1. Select "Price: Low to High"
2. Click "Search & Filter"
3. ✓ Should show: Cheapest products first

**Test 5: Pagination**
1. You see 8 products
2. Click "Next" button
3. ✓ Should show products 9-16
4. ✓ Filters should remain active

**Test 6: Combined Filters**
1. Search: "shoe"
2. Category: "Shoes"
3. Max Price: 2000
4. Sort: "Rating High to Low"
5. ✓ Should show filtered/sorted results

---

## 🔧 TROUBLESHOOTING

| Problem | Solution |
|---------|----------|
| "Cannot find module" | Run: `npm install` again |
| MongoDB connection error | Check if MongoDB is running or update `.env` with correct URI |
| Blank page | Run: `npm run seed` to add products |
| Port 3000 already in use | Change in `.env`: `PORT=3001` |
| CSS not loading | Restart server: `npm start` |
| Filters not working | Check query parameters in URL |

---

## 📁 PROJECT STRUCTURE (Final)

```
Assignment 3/
├── server.js               ← Main server file
├── seed.js                 ← Database seeding
├── package.json            ← Dependencies
├── .env                    ← Configuration
├── .gitignore              ← Git ignore file
├── README.md               ← Project docs
├── SETUP.md                ← This file
├── models/
│   └── Product.js          ← Schema definition
├── routes/
│   └── products.js         ← Route logic
├── views/
│   └── products.ejs        ← Product listing page
└── public/                 ← (for CSS, JS in future)
```

---

## 🎓 KEY CONCEPTS FOR DEMO/VIVA

### What to Explain:

1. **MongoDB Schema**: 5 required fields + 2 optional
2. **Pagination**: Show 8/page, use skip/limit
3. **Filtering**: Build MongoDB filter object
4. **Search**: Use regex for case-insensitive search
5. **Sorting**: Use MongoDB sort with -1/1 flags
6. **Filter Persistence**: Pass all params in URL

### Code Snippets to Know:

```javascript
// Pagination
skip = (page - 1) * 8;

// Search
{ $regex: search, $options: 'i' }

// Price Filter
{ $gte: minPrice, $lte: maxPrice }

// Sorting
{ price: 1 } // ascending
{ price: -1 } // descending
```

---

## ✨ FEATURES SUMMARY

✅ 25 sample products in database
✅ Search by product name
✅ Filter by 5 categories
✅ Filter by price range
✅ Sort by price/rating
✅ 8 products per page
✅ Filter persistence
✅ Responsive Bootstrap UI
✅ Simple beginner-friendly code
✅ Ready for demo/presentation

---

## 🚀 YOU'RE READY!

1. Run: `npm install`
2. Run: `npm run seed`
3. Run: `npm start`
4. Open: `http://localhost:3000`
5. Test all features
6. Ready for submission! 🎉

---

**Questions?** Check README.md or refer to code comments in respective files.
