// isLoggedIn Middleware - Check if user is logged in
const isLoggedIn = (req, res, next) => {
  if (req.session.user) {
    return next();
  }
  req.flash('error_msg', 'Please log in to continue');
  res.redirect('/login');
};

// isAdmin Middleware - Check if user is an admin
const isAdmin = (req, res, next) => {
  if (!req.session.user) {
    req.flash('error_msg', 'Please log in first');
    return res.redirect('/login');
  }

  if (req.session.user.role !== 'admin') {
    req.flash('error_msg', 'Access Denied! Only administrators can access this page.');
    return res.redirect('/products');
  }

  next();
};

// isLoggedOut Middleware - Check if user is NOT logged in (for login/register pages)
const isLoggedOut = (req, res, next) => {
  if (!req.session.user) {
    return next();
  }
  res.redirect('/products');
};

module.exports = {
  isLoggedIn,
  isAdmin,
  isLoggedOut
};
