# Assignment 4: Admin Panel System - Implementation Guide

## Overview

This document describes the Admin Panel System implementation for the e-commerce project. The admin panel provides a secure interface for product management with CRUD (Create, Read, Update, Delete) functionality and image upload capabilities.

---

## File Structure

```
assignment 4/
├── middleware/
│   └── upload.js                 # Multer configuration
├── routes/
│   ├── products.js               # Product display routes
│   └── adminRoutes.js            # Admin CRUD routes
├── views/
│   ├── products.ejs              # Customer product view
│   └── admin/
│       ├── dashboard.ejs         # Admin dashboard
│       ├── add-product.ejs       # Add product form
│       └── edit-product.ejs      # Edit product form
├── public/
│   ├── uploads/                  # Uploaded product images
│   ├── css/
│   ├── js/
│   └── ...
├── models/
│   └── Product.js                # Product schema
├── server.js                      # Main server file
├── package.json                   # Dependencies
└── ... (other files)
```

---

## Features Implemented

### 1. Admin Dashboard (`/admin`)
- Display total product count
- Show all products in a table format
- Table columns: Image, Name, Price, Category, Rating, Stock, Actions
- Edit and Delete buttons for each product
- Quick add product button
- Sidebar navigation

### 2. Product Creation (`/admin/add-product`)
- Form with fields:
  - Product Name (required)
  - Price in USD (required)
  - Category (required)
  - Rating (0-5, optional)
  - Stock (required)
  - Image upload (optional)
- Validation for all fields
- Image preview before upload
- Drag-and-drop image upload
- Error messages for invalid inputs

### 3. Product Editing (`/admin/edit/:id`)
- Load existing product data into form
- Display current product image
- Allow image replacement
- Update all product fields
- Validation for all fields

### 4. Product Deletion
- Delete button with confirmation popup
- Removes product from database
- Deletes associated image file from disk

### 5. Image Upload (Multer)
- Upload location: `/public/uploads/`
- Supported formats: JPG, PNG, GIF, WebP
- File size limit: 5MB
- Unique filename generation (timestamp + original name)
- Image path stored in MongoDB
- Automatic directory creation

### 6. Security
- Simple admin middleware for access control
- Can be extended with proper authentication
- Currently allows access via `?admin=true` parameter or environment variable

---

## Database Schema

### Product Model
```javascript
{
  name: String (required),
  price: Number (required),
  category: String (required),
  rating: Number (0-5, optional),
  stock: Number (required),
  image: String (path to image),
  description: String (optional)
}
```

---

## API Routes

### Admin Routes

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/admin` | Dashboard - List all products |
| GET | `/admin/add-product` | Show add product form |
| POST | `/admin/add-product` | Create new product |
| GET | `/admin/edit/:id` | Show edit product form |
| POST | `/admin/edit/:id` | Update product |
| GET | `/admin/delete/:id` | Delete product |

### Product Routes (Existing)
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/products` | Display products with filters, search, pagination |

---

## Middleware

### Multer Configuration (`middleware/upload.js`)

```javascript
// File storage configuration
const storage = multer.diskStorage({
  destination: './public/uploads',
  filename: 'timestamp-originalname'
});

// File filter
const fileFilter = (req, file, cb) => {
  // Accept: JPG, PNG, GIF, WebP
  // Reject other formats
};

// Limits
- Maximum file size: 5MB
```

### Admin Middleware (`routes/adminRoutes.js`)

Simple access control that checks for:
- `?admin=true` query parameter, OR
- `req.session.isAdmin` flag, OR
- `ADMIN_MODE=true` environment variable

---

## Validation Rules

### Add/Edit Product Validation

| Field | Rules |
|-------|-------|
| name | Required, non-empty |
| price | Required, must be > 0 |
| category | Required, non-empty |
| rating | Optional, must be 0-5 |
| stock | Required, must be >= 0 |
| image | Optional, image file only |

---

## UI/UX Features

### Admin Panel Design
- **Sidebar Navigation**: Quick access to dashboard and add product
- **Color Scheme**: Professional dark sidebar with light content area
- **Bootstrap 5**: Responsive grid system
- **Font Awesome Icons**: Visual icons for better UX
- **Responsive Tables**: Mobile-friendly product table
- **Success Messages**: Toast-style notifications after operations
- **Error Messages**: Clear validation error display

### Forms
- Drag-and-drop image upload
- Image preview before submission
- Bootstrap form styling
- Clear field labels with required indicators
- Input validation feedback

---

## How to Use

### For Admin Users

#### Accessing the Admin Panel
1. Navigate to `http://localhost:3000/admin?admin=true`
   - (or set `ADMIN_MODE=true` in .env for permanent access)

#### Adding a Product
1. Click "Add New Product" or navigate to `/admin/add-product`
2. Fill in product details
3. (Optional) Upload product image
4. Click "Add Product"
5. View confirmation message on dashboard

#### Editing a Product
1. Go to admin dashboard (`/admin`)
2. Click "Edit" button on product row
3. Update desired fields
4. (Optional) Upload new image
5. Click "Update Product"
6. View confirmation message

#### Deleting a Product
1. Go to admin dashboard (`/admin`)
2. Click "Delete" button on product row
3. Confirm deletion in popup
4. Product removed from database and view updated

---

## How to Extend

### Adding Authentication
Replace the simple middleware in `adminRoutes.js` with:
```javascript
const adminMiddleware = (req, res, next) => {
  // Check proper JWT or session auth
  if (!req.user || !req.user.isAdmin) {
    return res.redirect('/login');
  }
  next();
};
```

### Adding More Fields
1. Update Product schema in `models/Product.js`
2. Add field to admin forms
3. Update validation rules

### Customizing Styles
- Edit CSS in dashboard.ejs, add-product.ejs, edit-product.ejs
- or create separate CSS files in `public/css/`

---

## Testing Checklist

- [x] Dashboard loads and shows product count
- [x] Add product form displays correctly
- [x] Image upload and preview works
- [x] Product created and saved to MongoDB
- [x] Product appears in dashboard table
- [x] Edit form loads with existing data
- [x] Product update saves changes
- [x] Product image updates correctly
- [x] Delete confirmation shows
- [x] Product deletion removes from DB and disk
- [x] Image files stored in /public/uploads
- [x] Validation errors display
- [x] Success messages display
- [x] Responsive design on mobile

---

## Dependencies

- **express**: Web framework
- **mongoose**: MongoDB ODM
- **ejs**: Template engine
- **multer**: File upload middleware
- **dotenv**: Environment variables
- **bootstrap**: CSS framework (CDN)
- **font-awesome**: Icons (CDN)

---

## Environment Variables

Create a `.env` file (if not exists):
```
MONGODB_URI=mongodb://localhost:27017/ecommerce
PORT=3000
ADMIN_MODE=false  # Set to true for permanent admin access
```

---

## Running the Application

```bash
# Install dependencies
npm install

# Start server
npm start

# Access
- Store: http://localhost:3000/products
- Admin: http://localhost:3000/admin?admin=true
```

---

## Notes for Viva/Demo

1. **Simple Design**: Clean UI easy to explain
2. **Full CRUD**: Complete product management
3. **Image Upload**: Real file storage demonstration
4. **Validation**: Clear error handling
5. **Responsive**: Works on desktop and mobile
6. **Database**: Products persist in MongoDB
7. **Beginner-Friendly**: No complex architecture

---

## Troubleshooting

### Images not uploading
- Check `/public/uploads` directory exists
- Verify file size < 5MB
- Check file format (JPG, PNG, GIF, WebP)

### Admin routes not working
- Ensure adminRoutes.js is imported in server.js
- Check `?admin=true` parameter in URL
- Or set `ADMIN_MODE=true` in .env

### MongoDB connection errors
- Ensure MongoDB is running
- Check MONGODB_URI in .env

---

**Last Updated**: 2026-05-18  
**Version**: 1.0  
**Status**: Complete and Ready for Demo
